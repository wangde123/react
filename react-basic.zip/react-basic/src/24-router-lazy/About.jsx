import React, { Component } from "react";

console.log("about");
class About extends Component {
  state = {};
  render() {
    return <div>about组件</div>;
  }
}

export default About;
