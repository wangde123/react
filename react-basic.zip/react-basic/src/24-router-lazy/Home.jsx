import React, { Component } from "react";

console.log("home");
class Home extends Component {
  state = {};
  render() {
    return <div>home组件</div>;
  }
}

export default Home;
