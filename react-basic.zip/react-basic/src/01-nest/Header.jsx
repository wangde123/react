import React from "react";

const Header = () => {
  return <header>头部组件</header>;
};

export default Header;
