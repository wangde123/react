import { useState } from "react";

const useTodolist = () => {
  const [list, setList] = useState([
    {
      id: 1,
      name: "zhangsan",
    },
  ]);
  const [value, setValue] = useState("");
  const handleChange = (e) => {
    setValue(e.target.value);
  };
  const add = () => {
    setList((v) => [...v, { id: new Date().getTime(), name: value }]);
    setValue("");
  };

  return [list, value, handleChange, add];
};

export default useTodolist;
