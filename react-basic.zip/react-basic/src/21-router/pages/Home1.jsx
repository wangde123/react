import React, { Component } from "react";

class Home1 extends Component {
  state = {};
  render() {
    return <div>关于首页1</div>;
  }
}

export default Home1;
