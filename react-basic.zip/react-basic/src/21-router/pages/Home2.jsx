import React, { Component } from "react";

class Home2 extends Component {
  state = {};
  render() {
    return <div>关于首页2</div>;
  }
}

export default Home2;
