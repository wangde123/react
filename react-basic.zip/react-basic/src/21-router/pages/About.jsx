import React, { Component } from "react";

class About extends Component {
  state = {};
  render() {
    return <div>关于页面</div>;
  }
}

export default About;
