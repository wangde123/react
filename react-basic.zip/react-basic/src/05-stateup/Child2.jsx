import React from "react";

const Child2 = (props) => {
  return <div>child2组件 - {props.num}</div>;
};

export default Child2;
